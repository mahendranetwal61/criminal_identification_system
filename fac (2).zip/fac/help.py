import tkinter as tk
from tkinter import ttk
import pymysql

def fetch_data():
    # Establish a database connection
    no = tk.Tk()
    connection = pymysql.connect( host="localhost",
    user="root",
    password="",
    database="criminaldb")

    # Create a cursor to interact with the database
    cursor = connection.cursor()

    # Execute the query to fetch data
    query = "SELECT * FROM criminaldata"
    cursor.execute(query)

    # Fetch all the rows returned by the query
    rows = cursor.fetchall()

    # Close the cursor and database connection
    cursor.close()
    connection.close()

    # Create a new tkinter window
    window = tk.Toplevel(no)
    window.title("Fetched Data")

    # Create a tkinter Treeview widget to display the fetched data
    treeview = ttk.Treeview(window)
    treeview.pack(fill="both", expand=True)

    # Create a horizontal scrollbar for the Treeview
    scrollbar = ttk.Scrollbar(window, orient="horizontal", command=treeview.xview)
    scrollbar.pack(fill="x")

    # Configure the Treeview to use the scrollbar
    treeview.configure(xscrollcommand=scrollbar.set)

    # Configure the columns in the Treeview
    treeview["columns"] = ("id","Name", "Father's Name", "Mother's Name", "Gender", "DOB(yyyy-mm-dd)", "Blood Group",
                    "Identification Mark", "Nationality", "Religion", "Crimes Done")
    treeview.heading("id", text="id", anchor=tk.CENTER)
    treeview.heading("Name", text="Name", anchor=tk.CENTER)
    treeview.heading("Father's Name", text="Father's Name", anchor=tk.CENTER)
    treeview.heading("Mother's Name", text="Mother's Name", anchor=tk.CENTER)
    treeview.heading("Gender", text="Gender", anchor=tk.CENTER)
    treeview.heading("DOB(yyyy-mm-dd)", text="DOB(yyyy-mm-dd)", anchor=tk.CENTER)
    treeview.heading("Blood Group", text="Blood Group", anchor=tk.CENTER)
    treeview.heading("Identification Mark", text="Identification Mark", anchor=tk.CENTER)
    treeview.heading("Nationality", text="Nationality", anchor=tk.CENTER)
    treeview.heading("Religion", text="Religion", anchor=tk.CENTER)
    treeview.heading("Crimes Done", text="Crimes Done", anchor=tk.CENTER)

    # Populate the Treeview with the fetched data
    for row in rows:
        treeview.insert("", "end", values=row)

    # Run the tkinter event loop for the new window
    window.mainloop()

# Create the main tkinter window


fetch_data()
# Run the tkinter event loop
# no.mainloop()
